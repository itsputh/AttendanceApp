package ftmk.bitp3453.attendanceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Home extends AppCompatActivity {

    Button btnStart;
    TextView Welcome;
    TextView MainTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        btnStart = (Button) findViewById(R.id.btnStart);
        Welcome = (TextView) findViewById(R.id.Welcome);
        MainTitle = (TextView) findViewById(R.id.MainTitle);


    }
    public void fnStart(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }
}